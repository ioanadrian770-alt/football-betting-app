import React, {useEffect, useState} from 'react'

export default function App(){
  const [matches, setMatches] = useState([])
  const [predictions, setPredictions] = useState([])

  useEffect(()=>{
    fetch('/api/v1/matches/')
      .then(r=>r.json())
      .then(setMatches)
    fetch('/api/v1/predictions/')
      .then(r=>r.json())
      .then(setPredictions)
  },[])

  return (
    <div style={{fontFamily:'Arial, sans-serif', padding:20}}>
      <h1>Football Betting Platform - Scaffold</h1>
      <section>
        <h2>Matches</h2>
        <ul>
          {matches.map(m=>(
            <li key={m.match_id}>{m.date} — {m.home_team} vs {m.away_team} {m.score?`(${m.score})`:''}</li>
          ))}
        </ul>
      </section>
      <section>
        <h2>Predictions</h2>
        <ul>
          {predictions.map(p=>(
            <li key={p.match_id}>Match {p.match_id}: Home {p.p_home} — Draw {p.p_draw} — Away {p.p_away}</li>
          ))}
        </ul>
      </section>
    </div>
  )
}
