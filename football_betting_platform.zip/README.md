# Football Betting Platform - Scaffold

Aceasta este o versiune scaffold (schelet) a unui soft complet pentru pariuri fotbal, furnizată ca punct de plecare:
- Backend: FastAPI
- Frontend: React (Vite)
- ML: folder cu script de antrenare de bază
- Docker + docker-compose pentru rulare locală
- Exemple de date și instrucțiuni

## Conținut
- backend/: FastAPI app
- frontend/: React app (Vite)
- ml/: script simplu de antrenament
- docker-compose.yml, Dockerfile-uri

## Cum rulezi local (exemplu)
1. Asigură-te că ai Docker & docker-compose instalate.
2. Din directorul proiectului:
   ```bash
   docker-compose build
   docker-compose up
   ```
3. Backend va fi la: http://localhost:8000
   Frontend la: http://localhost:3000

Acesta este doar un scaffold. Funcționalitățile avansate (conectori de date, modele produse, backtesting complex) trebuie implementate peste acest schelet.
