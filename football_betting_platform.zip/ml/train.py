# Simplified ML training script (baseline) - uses sample CSV
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss, accuracy_score
import joblib
import os

DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'sample_matches.csv')
df = pd.read_csv(DATA_PATH)
# very small feature engineering example
df['home_adv'] = (df.home_goals - df.away_goals)
X = df[['home_adv']].fillna(0)
y = (df.home_goals > df.away_goals).astype(int)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LogisticRegression()
model.fit(X_train, y_train)
preds = model.predict_proba(X_test)
print('Log-loss:', log_loss(y_test, preds))
print('Accuracy:', accuracy_score(y_test, preds[:,1]>0.5))
joblib.dump(model, os.path.join(os.path.dirname(__file__), 'baseline_model.joblib'))
