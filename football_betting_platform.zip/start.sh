#!/bin/bash
echo "Build and run with docker-compose:"
echo "  docker-compose build"
echo "  docker-compose up"
