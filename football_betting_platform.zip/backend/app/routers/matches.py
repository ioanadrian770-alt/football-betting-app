from fastapi import APIRouter
from pydantic import BaseModel
from typing import List

router = APIRouter()

class Match(BaseModel):
    match_id: int
    date: str
    home_team: str
    away_team: str
    score: str | None = None

# sample in-memory data
SAMPLE_MATCHES = [
    {"match_id": 1, "date": "2025-08-01", "home_team": "Team A", "away_team": "Team B", "score": "2-1"},
    {"match_id": 2, "date": "2025-08-02", "home_team": "Team C", "away_team": "Team D", "score": None},
]

@router.get("/", response_model=List[Match])
async def list_matches():
    return SAMPLE_MATCHES
