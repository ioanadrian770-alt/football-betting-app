from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class PredictionResponse(BaseModel):
    match_id: int
    p_home: float
    p_draw: float
    p_away: float

# Dummy predictions
@router.get("/", response_model=list[PredictionResponse])
async def predictions():
    return [
        {"match_id": 1, "p_home": 0.55, "p_draw": 0.25, "p_away": 0.20},
        {"match_id": 2, "p_home": 0.40, "p_draw": 0.30, "p_away": 0.30},
    ]
