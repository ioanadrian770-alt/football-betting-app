from fastapi import FastAPI
from app.routers import matches, predictions

app = FastAPI(title="Football Betting API - Scaffold")

app.include_router(matches.router, prefix="/api/v1/matches", tags=["matches"])
app.include_router(predictions.router, prefix="/api/v1/predictions", tags=["predictions"])

@app.get("/")
async def root():
    return {"status": "ok", "message": "Football Betting API - scaffold running"}
